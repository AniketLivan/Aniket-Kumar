﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UserManagementConsoleApplication
{
  
    public class CUser
    {
        #region Member Variable
        private Int32 m_nId;        /*This is used to store the id of a user*/
        private string m_strFirstName;        /*This is used to store the first name of a user*/
        private string m_strLastName;        /*This is used to store the last name of a user*/
        private Int32 m_nAge;        /*This is used to store the age of a user*/
        #endregion

        #region Constructor
        //Default Constructors
        public CUser()
        {
            m_nId = 0;
            m_strFirstName = "";
            m_strLastName = "";
            m_nAge = 0;
        }

        //Parameterized Constructor
        public CUser(Int32 nId, string strFirstName, string strLastName, Int32 nAge)
        {
            m_nId = nId;
            m_strFirstName = strFirstName;
            m_strLastName = strLastName;
            m_nAge = nAge;
        }
        #endregion

        #region Property
    
        public Int32 Id
        {
            get { return m_nId; }
            set { m_nId = value; }
        }

      >
            public string FirstName
            {
                get { return m_strFirstName; }
                set { m_strFirstName = value; }
            }

      
        public string LastName
        {
            get { return m_strLastName; }
            set { m_strLastName = value; }
        }

        
        public Int32 Age
        {
            get { return m_nAge; }
            set { m_nAge = value; }
        }
        #endregion
    }
}