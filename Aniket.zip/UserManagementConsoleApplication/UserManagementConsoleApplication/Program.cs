﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data.SqlClient;

namespace UserManagementConsoleApplication
{

    class Program
    {
        // connection string for making connection for the crud operations to happen.
        public static String connectionString = ConfigurationSettings.AppSettings["connection"].ToString();


        /// <summary>
        /// This main method loads first when the application starts
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            // Function where the whole logic is defined.
            UserFunctions();
        }


        /// <summary>
        /// This method is called every time when the application loads and after performing the CRUD operations
        /// </summary>
        public static void UserFunctions()
        {
            // Heading to the console application
            Console.WriteLine("User Management System");

            // this function brings all the users from the database.
            GetAllUsers();

            // Options for the Crud operations goes here
            Console.Write("\n\n\nFor creating a user C, for Updating a user press U and for deleting a user press D\n");

            // It takes what option is selected
            ConsoleKeyInfo keyInfo = Console.ReadKey(false);

            // Cases for what operation is selected
            switch (keyInfo.Key)
            {
                // Case for Updating a User
                case ConsoleKey.U:
                    {
                        Console.Write("\n\nEnter the UserId which you want to update?\n");

                        //UserId for a user to have update operation 
                        string id = Console.ReadLine();

                        // Making sql connection with database to check if the user exists with this id.
                        using (SqlConnection con = new SqlConnection(connectionString))
                        {
                            // Opening connection state
                            con.Open();


                            // Query for checking the user with a particular userId
                            string queryIfUserExists = "SELECT user_id,first_name,last_name,age from pb_user_info where user_id=" + id;


                            // Sql Command to execute the query
                            using (SqlCommand cmd = new SqlCommand(queryIfUserExists, con))
                            {
                                // Sql DataReader for reading data 
                                SqlDataReader reader = cmd.ExecuteReader();

                                //Condition for checking is the reader has rows
                                if (reader.HasRows)
                                {
                                    // Object for getting user data from console window
                                    CUser oCUser = new CUser();
                                    oCUser.Id = Convert.ToInt32(id);
                                    Console.Write("\n\nEnter the new FirstName: ");
                                    oCUser.FirstName = Console.ReadLine();
                                    Console.Write("Enter the new LastName: ");
                                    oCUser.LastName = Console.ReadLine();
                                    Console.Write("Enter the new Age: ");
                                    string age = Console.ReadLine();
                                    // Condition to check if age is entered or not
                                    if (age != "")
                                    {
                                        oCUser.Age = Convert.ToInt32(age);
                                    }
                                    else
                                    {   
                                        Console.Write("Please enter an age for the user either it will set to 0.\n Enter Age: ");
                                        age = Console.ReadLine();
                                        if (age != "")
                                        {
                                            oCUser.Age = Convert.ToInt32(age);
                                        }
                                    }

                                    // Function to update the user with the enter values on the console window.
                                    UpdateUser(oCUser);
                                }
                                // If the user does not exists then this block will run
                                else
                                {
                                    Console.Write("\n User Id does not exists, please try with the user id which already exists. Press any key to continue");
                                    Console.ReadKey();
                                    Console.Clear();
                                    UserFunctions();
                                }


                            }
                        }


                        break;
                    }

                // Case for deleting a user
                case ConsoleKey.D:
                    {
                        Console.Write("\n\nEnter the UserId which you want to delete?\n");

                        //UserId for a user to have update operation
                        string id = Console.ReadLine();

                        // Making sql connection with database to check if the user exists with this id.
                        using (SqlConnection con = new SqlConnection(connectionString))
                        {
                            // Opening connection state
                            con.Open();

                            // Query for checking the user with a particular userId
                            string queryIfUserExists = "SELECT user_id,first_name,last_name,age from pb_user_info where user_id =" + id;

                            // Sql Command to execute the query
                            using (SqlCommand cmd = new SqlCommand(queryIfUserExists, con))
                            {
                                // Sql DataReader for reading data
                                SqlDataReader reader = cmd.ExecuteReader();

                                //Condition for checking is the reader has rows
                                if (reader.HasRows)
                                {

                                    // Function is called for deleting a user
                                    DeleteUser(id);
                                }
                                // if the entered user id not exists in the database then this block will run
                                else
                                {
                                    Console.Write("\n User Id does not exists, please try with the user id which already exists. Press any key to continue");
                                    Console.ReadKey();
                                    // for clearing the console window
                                    Console.Clear();
                                    // Function where the whole logic is defined.
                                    UserFunctions();
                                }


                            }
                        }

                        break;
                    }
                // Case for creating a User
                case ConsoleKey.C:
                    {

                        // Object for getting all the user details entered in the console window
                        CUser oCUser = new CUser();
                        Console.Write("\n\nEnter FirstName: ");
                        oCUser.FirstName = Console.ReadLine();
                        Console.Write("Enter LastName: ");
                        oCUser.LastName = Console.ReadLine();
                        Console.Write("Enter Age: ");
                        string age = Console.ReadLine();
                        // Condition to check if age is entered or not
                        if (age != "")
                        {
                            oCUser.Age = Convert.ToInt32(age);
                        }
                        else
                        {
                            Console.Write("Please enter an age for the user either it will set to 0.\n Enter Age: ");
                            age = Console.ReadLine();
                            if (age != "")
                            {
                                oCUser.Age = Convert.ToInt32(age);
                            }
                        }

                        // function for creating a user in database
                        CreateUser(oCUser);
                        break;
                    }
                // Case if the wrong option key is pressed
                default:
                    {
                        Console.Write("\n\nPlease enter a valid option. Press any key to continue.....");
                        Console.ReadKey();
                        // function for clearing the console window
                        Console.Clear();
                        // function where the whole logic is defined
                        UserFunctions();
                        break;
                    }
            }
        }


        /// <summary>
        /// This method is called for getting all the user details from the database.
        /// </summary>
        public static void GetAllUsers()
        {
            // Making sql connection with database 
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                // Opening connection state
                con.Open();


                // Query for getting all the users from database
                string GettingAllUsersQuery = "SELECT user_id,first_name,last_name,age from pb_user_info";

                // Sql Command to execute the query
                using (SqlCommand cmd = new SqlCommand(GettingAllUsersQuery, con))
                {
                    // Sql data reader to read the user details by column names
                    SqlDataReader reader = cmd.ExecuteReader();

                    // Writing the headers on the console screen
                    Console.Write("UserID\tFirstName\tLastName\tAge\n");
                    while (reader.Read())
                    {
                        // writing the users on the console window row by row
                        Console.Write((reader["user_id"]).ToString() + "\t" + (reader["first_name"]).ToString() + "\t\t" + (reader["last_name"]).ToString() + "\t\t" + (reader["age"]).ToString() + "\n");
                    }


                }
            }
        }

        /// <summary>
        /// This method is called for creating user in database
        /// </summary>
        /// <param name="oCUser">it contains all the user details which are to be inserted</param>
        public static void CreateUser(CUser oCUser)
        {
            // Making sql connection with database
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                // Opening connection state
                con.Open();

                string insertUserQuery = "INSERT into pb_user_info values('" + oCUser.FirstName + "','" + oCUser.LastName + "'," + oCUser.Age + ")";

                // Sql Command to execute the query
                using (SqlCommand cmd = new SqlCommand(insertUserQuery, con))
                {
                    cmd.ExecuteNonQuery();

                }
                Console.Write("User inserted successfully. Press any key to continue.......");
                Console.ReadKey();
                Console.Clear();
                UserFunctions();
            }
        }


        /// <summary>
        /// This method is called for updating a user in the database
        /// </summary>
        /// <param name="oCUser">it contains all the user details to be updated</param>
        public static void UpdateUser(CUser oCUser)
        {
            // Making sql connection with database
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                // Opening connection state
                con.Open();

                // Query for updating the user in database
                string updateUserQuery = "update pb_user_info set first_name= '" + oCUser.FirstName + "',last_name='" + oCUser.LastName + "',age=" + oCUser.Age + " where user_id=" + oCUser.Id;
                // Sql Command to execute the query
                using (SqlCommand cmd = new SqlCommand(updateUserQuery, con))
                {
                    cmd.ExecuteNonQuery();

                }
                Console.Write("User updated successfully. Press any key to continue......");
                Console.ReadKey();
                // function for clearing the console screen
                Console.Clear();
                // function where the whole logic goes.
                UserFunctions();
            }
        }

        /// <summary>
        /// This method is used for deleting a user in database.
        /// </summary>
        /// <param name="id"></param>
        public static void DeleteUser(string id)
        {
            // Making sql connection with database
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                // Opening connection state
                con.Open();

                // Query for deleting a user from database
                string deleteUserQuery = "DELETE from pb_user_info where user_id = " + id;

                // Sql Command to execute the query
                using (SqlCommand cmd = new SqlCommand(deleteUserQuery, con))
                {
                    cmd.ExecuteNonQuery();

                }
            }
            Console.Write("User deleted successfully. Press any key to continue......");
            Console.ReadKey();
            // function for clearing the console screen
            Console.Clear();
            // function where the whole logic goes.
            UserFunctions();
        }


    }
}
